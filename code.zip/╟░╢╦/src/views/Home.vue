
<template>
  <n-card hoverable>
    <n-result status="success" title="欢迎">
    </n-result>
  </n-card>
</template>

<script>
import { NCard, NResult } from "naive-ui";

export default {
  components: {
    NCard,
    NResult,
  },
};
</script>


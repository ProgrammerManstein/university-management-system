﻿namespace WebApp.Models
{
    public class StudentCourseScore
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int? Score { get; set; }
    }
}
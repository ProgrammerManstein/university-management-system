﻿namespace WebApp.Models
{
    public class SourcePlaceCount
    {
        public string SourcePlace { get; set; }
        public int Count { get; set; }
    }
}